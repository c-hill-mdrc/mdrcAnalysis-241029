#' @keywords internal
#' @import rlang
#' @importFrom magrittr %>%
#' @importFrom magrittr %<>%
#' @importFrom magrittr or
#' @importFrom magrittr set_colnames
#' @importFrom magrittr set_rownames
#' @importFrom magrittr use_series
"_PACKAGE"

